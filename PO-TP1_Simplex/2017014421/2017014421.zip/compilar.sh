#!/bin/bash
g++ main.cpp pl.cpp
